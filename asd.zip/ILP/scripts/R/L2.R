house_train <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_train_old.csv")
house_test <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv")

library(glmnet)
library(ggplot2)

model3 <- lm(Price~poly(Size,10,raw=T),house_train)
train_matrix <- poly(house_train$Size,10,raw=F)
test_matrix <- poly(house_test$Size,10,raw=F)

# ------------------------------------------------------------------------------

## Lambda = 0

# ------------------------------------------------------------------------------

lam_0 = glmnet(train_matrix, house_train$Price, alpha = 0)
lam_0_pre <- predict(lam_0, 
                     s = 0,             # Value for penalty parameter lambda
                     train_matrix)

# --------- Plot----------
plot_func <- function(pre_val){
  ggplot() + 
    geom_line(aes(x = house_train$Size, y = pre_val, col = 'Ridge (L2)'), size = 1.2) +
    geom_line(aes(x = house_train$Size, y = fitted(model3), col = 'Polynomial'), size = 1.2) +
    geom_point(aes(x = house_train$Size, y = house_train$Price), size = 1.5) +
    labs(col = 'Regression Type') +
    scale_color_manual(values = c("Ridge (L2)" = "darkolivegreen3",
                                  "Polynomial" = "lightcoral")) +
    ggtitle(expression(paste("Ridge Regression at ", lambda," = 0"))) + 
    xlab("Size") + ylab("Price") +
    theme_bw() +
    theme(panel.grid.major = element_line(colour = "white"),
          axis.text = element_text(size = 10),
          axis.title = element_text(size = 12),
          plot.title = element_text(hjust = 0.5),
          legend.title = element_text(face = 'bold'))
}

plot_func(lam_0_pre)


# ------------------------------------------------------------------------------

## Lambda = Inf

# ------------------------------------------------------------------------------


lam_inf = glmnet(train_matrix, house_train$Price, alpha = 0)
lam_inf_pre <- predict(lam_inf, s = 9999999999, train_matrix)
plot_func(lam_inf_pre)


# ------------------------------------------------------------------------------

## Selecting best lambda

# ------------------------------------------------------------------------------

lam_best <- cv.glmnet(train_matrix, house_train$Price, alpha = 0)
lam_best_pre <- predict(lam_best,s = lam_best$lambda.min, train_matrix)
plot_func(lam_best_pre)


# ------------------------------------------------------------------------------

## Plotting Coefficients of Size against their lambda values

# ------------------------------------------------------------------------------

library(tidyverse)
library(plotly)

lambda_col <- lam_0$lambda

# Adding lambda values after all coeff. columns
temp <- data.frame(t(matrix(lam_0$beta, ncol = 100, byrow = F)), lambda_col) 

temp <- temp %>%  gather(lambda_col)
names(temp) <- c('Lambda','Order','Standardized_Coefficients')

# Reordering levels to bring X10 in the end on legend
temp$Order <- as.factor(temp$Order)
levels(temp$Order) <- c('X1',  'X2', 'X3', 'X4', 'X5', 'X6', 'X7', 'X8', 'X9','X10')

# save below plot in a variable called "graph" for better Viz.
ggplot(temp) +
  geom_line(aes(Lambda,Standardized_Coefficients,col = Order))

# ggplotly(graph)


# ------------------------------------------------------------------------------

## RMSE Calculations

# ------------------------------------------------------------------------------

train_model <- predict(lam_best, s = lam_best$lambda.min, train_matrix)
rmse_train <- sqrt(mean((train_model - house_train$Price)^2))
rmse_train

test_model <- predict(lam_best, s = lam_best$lambda.min, test_matrix)
rmse_test <- sqrt(mean((test_model - house_test$Price)^2))
rmse_test


# ------------------------------------------------------------------------------

## Mathematics

# ------------------------------------------------------------------------------

## Finding out best lambda

plot(lam_best)
lam_best$lambda.min
lam_best$lambda.1se

