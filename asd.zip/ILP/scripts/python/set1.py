import subprocess as sp
tmp = sp.call('cls',shell=True)

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.preprocessing import scale
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import Ridge

import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv('data\hp_train_old.csv')
train_features = pd.read_csv('data\hp_train_old.csv',
                 usecols = [5])
train_target = pd.read_csv('data\hp_train_old.csv',
                 usecols = [2])
test_features = pd.read_csv('data\hp_test.csv',
                 usecols = [5])
test_target = pd.read_csv('data\hp_test.csv',
                 usecols = [2])

lm = make_pipeline(PolynomialFeatures(10), Ridge())
lm.fit(train_features, train_target)
pp = lm.predict(test_features)
#plt.plot(test_features,pp)
#plt.plot(train_features, train_target)
est = smf.ols('Price ~ Id + Location + Bedrooms + Bathrooms + Size', df).fit()
#print(est.summary().tables[1])

print(np.sqrt(mean_squared_error(pp,test_target)))