setwd("C:/Users/Sekhar_Subramanian/Desktop/Regularization & Boosting/")
house_train <- read.csv("./datasets/HousePrice_train.csv")
house_test <- read.csv("./datasets/HousePrice_test.csv")
plot(house_train$Size,house_train$Price)
points(house_test$Size,house_test$Price,pch=5)
summary(model)
lines(sort(house_train$Size),
      fitted(m10)[order(house_train$Size)],col="red",type="b")

model1 <- lm(Price~poly(Size,1,raw=T),house_train)
model2 <- lm(Price~poly(Size,3,raw=T),house_train)
model3 <- lm(Price~poly(Size,10,raw=T),house_train)

train_rmse1 <- sqrt(mean((model1$residuals)^2))
train_rmse2 <- sqrt(mean((model2$residuals)^2))
train_rmse3 <- sqrt(mean((model3$residuals)^2))

train_rmse1 <- sqrt(mean((predict(model1,house_train[,-3]) - house_train$Price)^2))
train_rmse2 <- sqrt(mean((predict(model3,house_train[,-3]) - house_train$Price)^2))
train_rmse3 <- sqrt(mean((predict(model3,house_train[,-3]) - house_train$Price)^2))

test_rmse1 <- sqrt(mean((predict(model1,house_test[,-3]) - house_test$Price)^2))
test_rmse2 <- sqrt(mean((predict(model2,house_test[,-3]) - house_test$Price)^2))
test_rmse3 <- sqrt(mean((predict(model3,house_test[,-3]) - house_test$Price)^2))


# Plotting models using ggplot2
install.packages("ggplot2")
library(ggplot2)
png("plot1.png",typ="cairo",width=960,height = 540)

ggplot()+theme_bw()+theme(panel.grid.major = element_line(colour = "white"),
                          axis.text = element_text(size = 10),
                          axis.title = element_text(size = 15))+
  geom_line(aes(x = house_train$Size,y=fitted(model1)),size = 1.2,col="#98c037")+
  geom_point(aes(x = house_train$Size,y=house_train$Price),size=1.5)+
  xlab("Size")+ylab("Price")

dev.off()

png("plot2.png",typ="cairo",width=960,height = 540)  
ggplot()+theme_bw()+theme(panel.grid.major = element_line(colour = "white"),
                           axis.text = element_text(size = 10),
                           axis.title = element_text(size = 15))+
  geom_line(aes(x = house_train$Size,y=fitted(model2)),size = 1.2,col="#80dfe2")+
  geom_point(aes(x = house_train$Size,y=house_train$Price),size=1.5)+
  ggtitle("Model 1")+xlab("Size")+ylab("Price")

dev.off()

png("plot3.png",typ="cairo",width=960,height = 540)
ggplot()+theme_bw()+theme(panel.grid.major = element_line(colour = "white"),
                          axis.text = element_text(size = 10),
                          axis.title = element_text(size = 15))+
  geom_line(aes(x = house_train$Size,y=fitted(model3)),size = 1.2,col="#cc87ff")+
  geom_point(aes(x = house_train$Size,y=house_train$Price),size=1.5)+
  xlab("Size")+ylab("Price")
dev.off()  
  

# ---- Compare the variance



train_data_old <- read.csv("./datasets/HousePrice_train_old.csv")
train_data_new <- read.csv("./datasets/HousePrice_train_new.csv")

model1_old <- lm(Price~poly(Size,1,raw=T),train_data_old)
model2_old <- lm(Price~poly(Size,3,raw=T),train_data_old)
model3_old <- lm(Price~poly(Size,10,raw=T),train_data_old)



model1_new <- lm(Price~poly(Size,1,raw=T),train_data_new)
model3_new <- lm(Price~poly(Size,10,raw=T),train_data_new)

coef(model1_old)
coef(model1_new)
dev_m1 <- 100*abs(coef(model1_old) - coef(model1_new))/ abs(coef(model1_old))

coef(model3_old)
coef(model3_new)
dev_m3 <- 100*abs(coef(model3_old) - coef(model3_new))/ abs(coef(model3_old))

# regularize model 2
library(glmnet)
library(ggplot2)

train_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_train)
test_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_test)
cv_model <- cv.glmnet(train_matrix,house_train$Price,alpha = 0)

best_lambda_ridge = cv_model$lambda.min
best_lambda_ridge

reg_lambda_ridge = cv_model$lambda.1se
reg_lambda_ridge

best_pred <- predict(cv_model,s = "lambda.min",train_matrix)

rmse_l2 <- sqrt(mean((best_pred - house_test$Price)^2))
rmse_l2
# plot(cv_model)
# plot(cv_model$glmnet.fit$beta)
# plot(house_train$Size,house_train$Price)


ggplot() + theme_bw() + theme(panel.grid.major = element_line(colour = "white"),
                          axis.text = element_text(size = 10),
                          axis.title = element_text(size = 15)) +
  
  geom_line(aes(x = house_train$Size,y = best_pred),size = 1.2,colour = 'red') +
  geom_line(aes(x = house_train$Size,y = fitted(model3)),size = 1.2,colour = '#cc87ff') +
  geom_point(aes(x = house_train$Size,y = house_train$Price),size = 1.5) +
  ggtitle("Regularized Model 3") + xlab("Size") + ylab("Price")


# plot(train_data_old$Size,train_data_new$Size)
# m1 <- lm(Price~poly(Size,1,raw=T),train_d)
# 
# 
# 
# var(fitted(model1_old)) < var(fitted(model3_old))
# mean(fitted(model1_old) - train_data_old$Price)
