house_train <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_train_old.csv")
house_test <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv")

##-----------------------------------------------------------------------

# one-hot encoding

df_train = house_train[,c(-1)]
house_train_encoded = with(df_train,
                           data.frame(model.matrix(~Location-1,df_train),
                                      Bedrooms,	Bathrooms, Size, Price))
colnames(house_train_encoded)


##-----------------------------------------------------------------------

# Reformatting Test data

df_test = house_test[,c(-1)]
house_test_encoded = with(df_test,
                          data.frame(model.matrix(~Location-1,df_test),
                                     Bedrooms,	Bathrooms, Size, Price))
new_cols = setdiff(colnames(house_train_encoded), colnames(house_test_encoded))
new_cols
house_test_encoded$LocationCambria <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationCreston <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationGrover.Beach <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationLompoc <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationLos.Osos <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationOceano <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationTempleton <- rep(0,nrow(house_test_encoded))
# colnames(house_test_encoded)[1] <- 'Location.Arroyo.Grande'
# colnames(house_test_encoded)[15] <- 'Location.Cambria'

setdiff(colnames(house_test_encoded), colnames(house_train_encoded))
house_test_encoded <- subset(house_test_encoded, select = -c(LocationBuellton, LocationNew.Cuyama, LocationPismo.Beach))

colnames(house_train_encoded)
colnames(house_test_encoded)


##-----------------------------------------------------------------------

# OLS

ml <- lm(Price~., data = house_train_encoded)
rmse_ols <- sqrt(mean((predict(ml,house_test_encoded[,-11]) - house_test_encoded$Price)^2))
rmse_ols


# L2 RMSE

ml = lm(Price~., data = house_train_encoded)
l2_model <- cv.glmnet(model.matrix(ml),house_train_encoded$Price,alpha=0)

# best_pred <- predict(l2_model,s = l2_model$lambda.min,model.matrix(lm(Price~., data = house_test_encoded)))
pred_l2 <- predict(l2_model,s = l2_model$lambda.min,model.matrix(lm(Price~., data = house_test_encoded)))
rmse_l2 <- sqrt(mean((pred_l2 - house_test_encoded$Price)^2))
rmse_l2


# L1 RMSE

ml = lm(Price~., data = house_train_encoded)
l1_model <- cv.glmnet(model.matrix(ml),house_train_encoded$Price,alpha=1)

# best_pred <- predict(l2_model,s = l2_model$lambda.min,model.matrix(lm(Price~., data = house_test_encoded)))
pred_l1 <- predict(l1_model,s = l1_model$lambda.min,model.matrix(lm(Price~., data = house_test_encoded)))
rmse_l1 <- sqrt(mean((pred_l1 - house_test_encoded$Price)^2))
rmse_l1




# Elastic Net

library(glmnet)
ml = model.matrix(Price~.,house_train_encoded)

en_model <- cv.glmnet(ml,house_train_encoded$Price,alpha=0.5)
en_model

pred_en <- predict(en_model,s = en_model$lambda.min, model.matrix(lm(Price~., data = house_test_encoded)))

rmse_en <- sqrt(mean((pred_en - house_test_encoded$Price)^2))
rmse_en


