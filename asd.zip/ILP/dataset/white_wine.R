orig <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\imdb.csv")

## ---------------------------------------------------------------------
# Splitting Original data into training and testing parts
smp_size <- floor(0.7 * nrow(orig))
set.seed(42)
train_ind <- sample(seq_len(nrow(orig)), size = smp_size)
train_data <- orig[train_ind, ]
test_data <- orig[-train_ind, ]

## ---------------------------------------------------------------------

# Applying linear regression

model_lr <- lm(formula = imdb_score~., data = train_data)

rmse_train_lr <- sqrt(mean((model_lr$residuals)^2))
rmse_train_lr

rmse_test_lr <- sqrt(mean((predict(model_lr,test_data) - test_data$imdb_score)^2))
rmse_test_lr


## ---------------------------------------------------------------------

# Applying L1 regularization

library(glmnet)

set.seed(42)
# train_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_train)
# test_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_test)

l1_mat <- model.matrix(object = imdb_score~., data = train_data)
model_l1 = cv.glmnet(l1_mat,
                  train_data$imdb_score,
                  alpha = 1)
# model_l1$lambda.min
best_pred_coef <- predict(model_l1,s = model_l1$lambda.min,l1_mat,type = "coefficients") 
best_pred_coef


l1_pre = model.matrix(imdb_score~.,test_data)

best_pred <- predict(model_l1,s = model_l1$lambda.min,l1_pre)
rmse_l1 <- sqrt(mean((best_pred - test_data$imdb_score)^2))
rmse_l1

rmse_train_lr
rmse_test_lr
rmse_l1

# -------------

# Plot

library(ggplot2)
library(tidyr)  # gather

lamb_all <- predict(model_l1,s = model_l1$lambda,l1_mat,type="coefficients") 
df <- cbind(as.data.frame(as.matrix(t(lamb_all))),as.data.frame(model_l1$lambda))
l1 = df[,c(-1,-2)] # Excluding the Intercept
colnames(l1)[15] <- 'lambda'

l1 <- l1 %>%
  gather(column,value,-lambda)


ggplot(l1) + geom_line(aes(lambda,value, col = column)) + 
  geom_vline(xintercept = model_l1$lambda.min) +
  ggtitle("L1 variable selection") + xlab("Lambda") + ylab("Coefficients")
