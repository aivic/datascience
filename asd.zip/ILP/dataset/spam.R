train_data <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\dataset\\spam_train_data.csv")
test_data <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\dataset\\spam_test_data.csv")


model1 <- glm(spam~word_freq_free+word_freq_credit+word_freq_receive+
                word_freq_money+capital_run_length_total,
              train_data,family = binomial(link = "logit"))
model2 <- glm(spam~.,train_data,family = binomial(link = "logit"))


# Confusion matrix on train data for Model1
m1_train <- ifelse(predict(model1,type = "response",train_data) >= 0.5, 1,0)
m1_cm <- addmargins(table(m1_train,train_data$spam))
train1_acc <- (m1_cm[1] + m1_cm[5]) / m1_cm[9] * 100
train1_acc

# Confusion matrix on test data for Model1
m1_test <- ifelse(predict(model1,type = "response",test_data) >= 0.5, 1,0)
m1_cm <- addmargins(table(m1_test,test_data$spam))
test1_acc <- (m1_cm[1] + m1_cm[5]) / m1_cm[9] * 100
test1_acc

# Confusion matrix on train data for Model2
m2_train <- ifelse(predict(model2,type = "response",train_data) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_train,train_data$spam))
train2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
train2_acc

# Confusion matrix on test data for Model2
m2_test <- ifelse(predict(model2,type = "response",test_data) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_test,test_data$spam))
test2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
test2_acc


###------------------------------------------------------------------------------------

# L2 regularization

library(glmnet)
# train_matrix <- model.matrix(spam~poly(Size,10,raw=T),house_train)
# test_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_test)
l2_model <- cv.glmnet(model.matrix(model2),train_data$spam,alpha=0)
l2_model

best_pred <- predict(l2_model,s = l2_model$lambda.min,model.matrix(spam~., data = test_data))

plot(l2_model)
plot(l2_model$glmnet.fit$beta)


# Confusion matrix on train data for Model2
m2_train <- ifelse(predict(l2_model,type = "response",model.matrix(spam~., data = train_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_train,train_data$spam))
l2_train2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
l2_train2_acc

# Confusion matrix on test data for Model2
m2_test <- ifelse(predict(l2_model,type = "response",model.matrix(spam~., data = test_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_test,test_data$spam))
l2_test2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
l2_test2_acc



###--------------------------------------------------------------------------------------

# L1 regularization

l1_model <- cv.glmnet(model.matrix(model2),train_data$spam,alpha=1)
l1_model

best_pred <- predict(l1_model,s = l1_model$lambda.min,model.matrix(spam~., data = train_data),type="coefficients") 
best_pred
best_pred[best_pred!=0]

# Confusion matrix on train data for Model2
m2_train <- ifelse(predict(l1_model,type = "response",model.matrix(spam~., data = train_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_train,train_data$spam))
l1_train2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
l1_train2_acc

# Confusion matrix on test data for Model2
m2_test <- ifelse(predict(l1_model,type = "response",model.matrix(spam~., data = test_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_test,test_data$spam))
l1_test2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
l1_test2_acc


# L1 plot

library(ggplot2)
library(magrittr) # %>%
library(tidyr)  # gather

lamb_all <- predict(l1_model,s = l1_model$lambda,model.matrix(spam~., data = test_data),type="coefficients") 
df <- cbind(as.data.frame(as.matrix(t(lamb_all))),as.data.frame(l1_model$lambda))
l1 = df[,c(-1,-2)] # Excluding the Intercept
colnames(l1)[58] <- 'lambda'

l1 <- l1 %>%
  gather(column,value,-lambda)


ggplot(l1) + geom_line(aes(lambda,value, col= column)) + 
  geom_vline(xintercept = l1_model$lambda.min) +
  ggtitle("L1 variable selection")+xlab("Lambda")+ylab("Coefficients")


###--------------------------------------------------------------------------------------

# Elastic-Net regularization

en_model <- cv.glmnet(model.matrix(model2),train_data$spam,alpha=0.9)
en_model

best_pred <- predict(en_model,s = en_model$lambda.min,model.matrix(spam~., data = train_data),type="coefficients") 
# best_pred

# Confusion matrix on train data for Model2
m2_train <- ifelse(predict(en_model,type = "response",model.matrix(spam~., data = train_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_train,train_data$spam))
en_train2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
en_train2_acc

# Confusion matrix on test data for Model2
m2_test <- ifelse(predict(en_model,type = "response",model.matrix(spam~., data = test_data)) >= 0.5,1,0)
m2_cm <- addmargins(table(m2_test,test_data$spam))
en_test2_acc <- (m2_cm[1] + m2_cm[5]) / m2_cm[9] * 100
en_test2_acc


## Parameter tuning
library(caret)
lambda.grid <- 10^seq(2, -2, length = 100)
alpha.grid <- seq(0, 1, length = 10)

tc <- trainControl(method = "repeatedCV", number = 10, repeats = 5)

sg <- expand.grid(.alpha = alpha.grid, .lambda = lambda.grid)
t <- train(spam~., data = train_data, method = "glmnet", tuneGrid = sg, trControl = tc, standardize = TRUE, maxit = 1000000)
plot(t)
t$bestTune
coef(t$finalModel, s= t$bestTune$lambda)


###--------------------------------------------------------------------------------------

# Variable Selection

model_emp = glm(spam~1,train_data,family = binomial(link = "logit"))
model_full = glm(spam~.,train_data,family = binomial(link = "logit"))

model_forward <- step(model_emp, scope=list(lower = model_emp, upper = model_full), direction="forward")
model_forward$coefficients

###--------------------------------------------------------------------------------------

# All methods accuracies

train2_acc
l2_train2_acc
l1_train2_acc

test2_acc
l2_test2_acc
l1_test2_acc
