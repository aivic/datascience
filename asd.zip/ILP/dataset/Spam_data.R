setwd("C:/Users/Sekhar_Subramanian/Desktop/Regularization & Boosting/")
train_data <- read.csv("./datasets/spam_train_data.csv")
test_data <- read.csv("./datasets/spam_test_data.csv")


model1 <- glm(spam~word_freq_free+word_freq_credit+word_freq_receive+
                word_freq_money+capital_run_length_total,
              train_data,family = binomial(link = "logit"))

model2 <- glm(spam~.,train_data,family = binomial(link = "logit"))

# Confusion matrix on train data for Model1
m1_pred_train <- ifelse(predict(model1,type = "response",train_data) >= 0.5,
                           1,0)
addmargins(table(m1_pred_train,train_data$spam))

# Confusion matrix on train data for Model2
m2_pred_train <- ifelse(predict(model2,type = "response",train_data) >= 0.5,
                           1,0)
addmargins(table(m2_pred_train,train_data$spam))

# Confusion matrix on test data for Model1
m1_pred_test <- ifelse(predict(model1,type = "response",test_data) >= 0.5,
                        1,0)
addmargins(table(m1_pred_test,test_data$spam))

# Confusion matrix on test data for Model2
m2_pred_test <- ifelse(predict(model2,type = "response",test_data) >= 0.5,
                        1,0)
addmargins(table(m2_pred_test,test_data$spam))

