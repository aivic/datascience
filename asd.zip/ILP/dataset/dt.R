library(tree)
library(xlsx)
train_data <- read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_train_old.csv')
test_data <- read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv')
## ---------------------------------------------------------------------
# Splitting Training data into 2 parts
smp_size <- floor(0.5 * nrow(train_data))
set.seed(123)
train_ind <- sample(seq_len(nrow(train_data)), size = smp_size)
train1 <- train_data[train_ind, ]
train2 <- train_data[-train_ind, ]

## ---------------------------------------------------------------------
# Deploying tree on each training data

t1 <- tree(Price~., train1[,-1])
summary(t1)
t1

t2 <- tree(Price~., train2[,-1])
summary(t2)
t2

plot(t1)
text(t1, pretty = 0)

plot(t2)
text(t2, pretty = 0)

pred1 <- predict(t1, test_data[,c(-1,-3)])
pred1 <- matrix(pred1, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean((pred1 - test)^2))


pred2 <- predict(t2, test_data[,c(-1,-3)])
pred2 <- matrix(pred2, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean((pred2 - test)^2))



## ---------------------------------------------------------------------
# Bagging

library(randomForest)

# Bagged Tree 1
# here mtry = 4 means we're considering all 4 predictors
bagged_tree1 <- randomForest(Price~.,train1[,-1], mtry = 4, importance = TRUE)

test_data$Location <- factor(test_data$Location, levels = levels(train1$Location))

bag_pred1 <- predict(bagged_tree1, test_data[,c(-1,-3)])
bag_pred1 <- matrix(bag_pred1, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean(((bag_pred1 - test)^2),na.rm = T))

# Bagged Tree 2
bagged_tree2 <- randomForest(Price~.,train1[,-1], mtry = 4, importance = TRUE)
test_data <- read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv')
test_data$Location <- factor(test_data$Location, levels = levels(train2$Location))

bag_pred2 <- predict(bagged_tree2, test_data[,c(-1,-3)])
bag_pred2 <- matrix(bag_pred2, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean(((bag_pred2 - test)^2),na.rm = T))

## ---------------------------------------------------------------------

# Random Forest

# Bagged Tree 1
# here mtry = 2 means we're considering only 2 predictors
rf_tree1 <- randomForest(Price~.,train1[,-1], mtry = 2, importance = TRUE)
test_data <- read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv')
test_data$Location <- factor(test_data$Location, levels = levels(train1$Location))

rf_pred1 <- predict(rf_tree1, test_data[,c(-1,-3)])
rf_pred1 <- matrix(rf_pred1, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean(((rf_pred1 - test)^2),na.rm = T))

# Bagged Tree 2
rf_tree2 <- randomForest(Price~.,train1[,-1], mtry = 2, importance = TRUE)
test_data <- read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv')
test_data$Location <- factor(test_data$Location, levels = levels(train2$Location))

rf_pred2 <- predict(rf_tree2, test_data[,c(-1,-3)])
rf_pred2 <- matrix(rf_pred2, nrow = 1)
test <- matrix(test_data[,"Price"], nrow = 1)

sqrt(mean(((rf_pred2 - test)^2),na.rm = T))
