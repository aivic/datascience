# Reading the data from CSV files to R
house_train <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_train_old.csv")

house_test <- read.csv("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_test.csv")

# Building 3 models to predict the price of the house based on its size
model1 <- lm(Price~poly(Size,1,raw=T),house_train)
model2<- lm(Price~poly(Size,3,raw=T),house_train)
model3 <- lm(Price~poly(Size,10,raw=T),house_train)
model1
library(xlsx)
write.csv(file = "D:\\p.csv",data.frame(predict(model2)))
plot(house_train$Size, house_train$Price)
plot(house_train$Size, predict(model2))

train_rmse1 <- sqrt(mean((model1$residuals)^2))
train_rmse2 <- sqrt(mean((model2$residuals)^2))
train_rmse3 <- sqrt(mean((model3$residuals)^2))

train_rmse1
train_rmse2
train_rmse3

test_rmse1 <- sqrt(mean((predict(model1,house_test[,-3]) - house_test$Price)^2))
test_rmse2 <- sqrt(mean((predict(model2,house_test[,-3]) - house_test$Price)^2))
test_rmse3 <- sqrt(mean((predict(model3,house_test[,-3]) - house_test$Price)^2))

test_rmse1
test_rmse2
test_rmse3

library(glmnet)
library(ggplot2)

set.seed(1)
train_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_train)
test_matrix <- model.matrix(Price~poly(Size,10,raw=T),house_test)

out = glmnet(train_matrix,house_train$Price,alpha = 0)
best_pred <- predict(out, s = 9999999999, train_matrix)

ggplot()+theme_bw()+theme(panel.grid.major = element_line(colour = "white"),
                          axis.text = element_text(size = 10),
                          axis.title = element_text(size = 15))+
  
  geom_line(aes(x = house_train$Size,y = best_pred),size = 1.2,colour = 'red')+
  geom_line(aes(x = house_train$Size,y = fitted(model3)),size = 1.2,colour = '#cc87ff')+
  geom_point(aes(x = house_train$Size,y = house_train$Price),size=1.5)+
  ggtitle("Alpha = inf")+xlab("Size")+ylab("Price")

rmse_l2 <- sqrt(mean((best_pred - house_test$Price)^2))
rmse_l2

## One hot encoding
df_train = house_train[,c(-1)]
house_train_encoded = with(df_train,
                         data.frame(model.matrix(~Location-1,df_train),
                                    Bedrooms,	Bathrooms, Size, Price))
colnames(house_train_encoded)

## L1 regularization
library(xlsx)
library(glmnet)
library(ggplot2)
set.seed(0)
# house_train_encoded <- read.xlsx("D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\scripts\\python\\data\\hp_train_old_encoded.xlsx", sheetName = 'Sheet1')
new_model = model.matrix(Price~.,house_train_encoded)

cv_mod <- cv.glmnet(new_model,house_train_encoded$Price,alpha=1)
cv_mod

best_pred <- predict(cv_mod,s = cv_mod$lambda.min,new_model,type="coefficients") 
best_pred
best_pred[best_pred!=0]



## Variable Selection plot

library(magrittr) # %>%
library(tidyr)  # gather

lamb_all <- predict(cv_mod,s = cv_mod$lambda,new_model,type="coefficients") 
df <- cbind(as.data.frame(as.matrix(t(lamb_all))),as.data.frame(cv_mod$lambda))
l1 = df[,c(-1,-2)] # Excluding the Intercept
colnames(l1)[18] <- 'lambda'

l1 <- l1 %>%
  gather(column,value,-lambda)


ggplot(l1) + geom_line(aes(lambda,value, col= column)) + 
  geom_vline(xintercept = cv_mod$lambda.min) +
  ggtitle("L1 variable selection")+xlab("Lambda")+ylab("Coefficients")


## L1 RMSE

df_test = house_test[,c(-1)]
house_test_encoded = with(df_test,
                     data.frame(model.matrix(~Location-1,df_test),
                                Bedrooms,	Bathrooms, Size, Price))
new_cols = setdiff(colnames(house_train_encoded), colnames(house_test_encoded))
new_cols
house_test_encoded$LocationCambria <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationCreston <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationGrover.Beach <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationLompoc <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationLos.Osos <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationOceano <- rep(0,nrow(house_test_encoded))
house_test_encoded$LocationTempleton <- rep(0,nrow(house_test_encoded))
# colnames(house_test_encoded)[1] <- 'Location.Arroyo.Grande'
# colnames(house_test_encoded)[15] <- 'Location.Cambria'

setdiff(colnames(house_test_encoded), colnames(house_train_encoded))
house_test_encoded <- subset(house_test_encoded, select = -c(LocationBuellton, LocationNew.Cuyama, LocationPismo.Beach))

colnames(house_train_encoded)
colnames(house_test_encoded)


test_model = model.matrix(Price~.,house_test_encoded)
test_model
best_pred <- predict(cv_mod,s = cv_mod$lambda.min,test_model) 
rmse_l1 <- sqrt(mean((best_pred - house_test_encoded$Price)^2))
rmse_l1


orig_model = lm(Price~.,house_train_encoded)
orig_rmse <- sqrt(mean((predict(orig_model,house_test_encoded[-11]) - house_test_encoded$Price)^2))
orig_rmse
