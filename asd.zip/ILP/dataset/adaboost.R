install.packages("adabag")
library(adabag);
adadata<-read.csv('D:\\Data Science\\ML_Statistical Learning\\Regularization\\ILP\\dataset\\bank-full.csv')
adaboost<- boosting(y~., data=adadata, boos=TRUE, mfinal=20,coeflearn='Breiman')
summary(adaboost)
adaboost$trees
adaboost$weights
adaboost$importance
errorevol(adaboost,adadata)
predict(adaboost,adadata)
t1<-adaboost$trees[[1]]
library(tree)
plot(t1)
text(t1,pretty=0)


library(xlsx)
df <- read.xlsx("C:\\Users\\vivek.kumar80\\Desktop\\ab.xlsx", sheetIndex = 1)
df$T <- factor(df$T)
ada_model <- boosting(T~., data=df, mfinal = 4, boos=TRUE,control=rpart.control(minsplit=0,cp=0))
ada_model$trees
ada_model
t1 <- ada_model$trees[[1]]


t1
plot(df$X, df$Y,main = 'Classification Data', col = df$T, xlab = 'X', ylab = 'Y', pch = 19)
text(1.2, 1,'D')
text(5, 1.8,'E')
text(5, 4.8,'B')
text(1.2, 5,'A')
text(3, 2.8,'C')



library(rpart)
install.packages("rpart.plot")
library(rpart.plot)
rpart.plot(t1,type = 0,extra = 0)

##==============================================================
# derivation

?boosting

